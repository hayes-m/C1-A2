	function myMenu(){		
	document.getElementById("myMenu").classList.toggle("open");
	}		/* This function opens the menu when the button is clicked */

	window.onclick = function(event) {
	  if (!event.target.matches('.button')) {

		var dropdowns = document.getElementsByClassName("menu");
		var i;
		for (i = 0; i < dropdowns.length; i++) {
		  var openDropdown = dropdowns[i];
		  if (openDropdown.classList.contains('open')) {
			openDropdown.classList.remove('open');
		  }
		}
	  }
	}		/* This function closes the menu by clicking anywhere outside of it */